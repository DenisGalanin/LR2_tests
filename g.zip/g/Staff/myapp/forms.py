from .models import Task
from django.forms import ModelForm, TextInput, NumberInput

class TaskForm(ModelForm):
    class Meta:
        model = Task
        fields = ["name", "place", "price", "square"]
        widgets ={
            "name": TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Название'
            }),
            "place": TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Тип'
            }),
            "price": NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Цена'
            }),
            "square": NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Размеры'
            }),
        }